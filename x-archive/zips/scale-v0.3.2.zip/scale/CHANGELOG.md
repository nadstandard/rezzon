# REZZON Scale — Changelog

## [0.3.2] - 2025-01-01

### Added
- **Path Template Parsing** — Full support for `{viewport}`, `{responsive}`, `{ratio}` variables in output paths
  - `parsePathTemplate()` — Detects template variables
  - `resolvePathTemplate()` — Resolves variables to actual values
  - Token count calculation respects path template expansion

- **Height Generation from Ratios** — Generate height tokens from width tokens
  - `generateHeightTokensForRatio()` — Calculate heights using ratio multiplier
  - Separate width/height prefixes (`widthPrefix`, `heightPrefix`)
  - Preview shows both width and height tokens

- **Full Token Export** — `generateAllTokensForFolder()` generates tokens with:
  - Full paths resolved from templates
  - Viewport/responsive/ratio metadata per token
  - Expansion across all viewports and responsive variants

### Changed
- `generateBaseWidthTokens()` extracted as internal helper
- `calculateFolderTokenCount()` now respects path template variables
- Demo data updated with proper path templates

---

## [0.3.1] - 2025-01-01

### Added
- **Generator connected to OutputFolders** — Token preview shows real calculated values
  - `getTokenPreviewForFolder()` — Get preview tokens for UI
  - `FolderGeneratorContext` — Context object for token generation

### Fixed
- Token preview no longer shows hardcoded placeholder values
- Token count dynamically recalculates on folder configuration changes

---

## [0.3.0] - 2025-12-30

### Added
- **Output Folders Architecture** — Complete redesign of Generators view with user-configurable output folder system
  - Folder tree panel with hierarchical nesting support
  - Folder configuration panel with path templates, token prefixes
  - Per-folder modifier, responsive variant, and ratio selection
  - Token preview panel showing generated tokens for selected folder

### New Types
- `OutputFolder` interface with full configuration:
  - `path` — Output path template with `{viewport}`, `{responsive}`, `{ratio}` variables
  - `tokenPrefix` — Prefix for generated token names
  - `enabledModifiers` — Selected modifier IDs
  - `enabledResponsiveVariants` — Selected responsive variant IDs
  - `multiplyByRatio` — Toggle for ratio multiplication
  - `generateHeight` — Toggle for height generation from ratios

### New Store Actions
- `addOutputFolder`, `updateOutputFolder`, `removeOutputFolder`
- `selectFolder` — Folder selection in tree
- `toggleFolderModifier`, `toggleFolderResponsive`, `toggleFolderRatio`
- `recalculateFolderTokenCounts`

### UI Components
- New `GeneratorsView` with 4-column layout:
  1. Folders panel (260px) — tree view with CRUD
  2. Preview panel (flex) — token preview table
  3. Config panel (320px) — folder configuration
  4. Sidebar (220px) — global definitions

- `FolderModal` for add/edit output folders

### Changed
- Store now includes `selectedFolderId` for folder selection state
- Session export/import includes `outputFolders` array

---

## [0.2.0] - 2025-12-24

### Added
- Generators view with responsive variants
- Modifier management (add/edit/delete)
- Ratio families (add/edit/delete)
- Viewport behaviors per responsive variant
- Token count calculations

---

## [0.1.0] - 2025-12-22

### Added
- Initial Parameters view
- Viewport and Style management
- Base and Computed parameters
- Basic token generation engine
